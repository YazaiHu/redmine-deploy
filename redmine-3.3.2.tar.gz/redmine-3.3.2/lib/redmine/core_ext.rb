Dir[File.dirname(__FILE__) + "/core_ext/*.rb"].each { |file| require(file) }
